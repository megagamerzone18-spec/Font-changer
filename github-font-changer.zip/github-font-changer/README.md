# 🎨 Font Changer - Desktop Aplikacija

Desktop aplikacija za menjanje fontova u realnom vremenu!

## ⚡ Preuzmi EXE (BEZ Python instalacije)

### Automatski Build:
1. Klikni na **"Actions"** tab gore
2. Klikni na poslednji uspešan build (zeleni ✅)
3. Scroll dole do **"Artifacts"**
4. Preuzmi **"FontChanger-Windows"** ZIP
5. Raspakuj i pokreni **FontChanger.exe**

### Ručno pokretanje build-a:
1. Idi na **"Actions"** tab
2. Klikni na **"Build Windows EXE"** workflow
3. Klikni **"Run workflow"** dugme (desno)
4. Izaberi **"main"** branch
5. Klikni **"Run workflow"**
6. Sačekaj 2-3 minuta
7. Preuzmi EXE iz Artifacts

## ✨ Funkcije

- 🎨 Izaberi font iz liste svih sistemskih fontova
- 📏 Podesi veličinu (8-72px)
- 💪 Izaberi debljinu (Normal/Bold)
- 🎭 Izaberi stil (Normal/Italic)
- 🌈 Izaberi boju teksta
- 📋 Kopiraj tekst u clipboard
- 💾 Sačuvaj tekst kao .txt fajl
- 🗑️ Obriši tekst
- 👁️ Vidi promene UŽIVO

## 🖥️ Sistemski zahtevi

- Windows 7 ili noviji
- 50 MB slobodnog prostora
- Nema potrebe za Python instalacijom!

## 📸 Kako izgleda

Desktop aplikacija sa dva panela:
- **Leva strana:** Kontrole za font, veličinu, stil, boju
- **Desna strana:** Tekst editor sa live preview

## 🐛 Problemi?

Ako EXE ne radi:
- Proveri Windows Defender (možda blokira nepoznate aplikacije)
- Klikni desni klik → Properties → "Unblock" checkbox
- Pokreni kao Administrator

## 📝 Licenca

Besplatno za ličnu i komercijalnu upotrebu.

---

**Napravljeno sa ❤️ za lakše menjanje fontova!**
