import tkinter as tk
from tkinter import ttk, scrolledtext, font, colorchooser, filedialog, messagebox
import os

class FontChangerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Font Changer - Desktop App")
        self.root.geometry("900x700")
        self.root.configure(bg='#f0f0f0')
        
        # Dostupni fontovi
        self.available_fonts = sorted(font.families())
        
        # Default vrednosti
        self.current_font = "Arial"
        self.current_size = 14
        self.current_weight = "normal"
        self.current_slant = "roman"
        self.current_color = "#000000"
        
        self.create_widgets()
        self.update_text_preview()
        
    def create_widgets(self):
        # Header
        header_frame = tk.Frame(self.root, bg='#7360f2', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        title = tk.Label(header_frame, text="✍️ Font Changer", 
                        font=('Arial', 24, 'bold'), 
                        bg='#7360f2', fg='white')
        title.pack(pady=20)
        
        # Main container
        main_container = tk.Frame(self.root, bg='#f0f0f0')
        main_container.pack(fill='both', expand=True, padx=20, pady=20)
        
        # Left panel - Controls
        left_panel = tk.Frame(main_container, bg='white', relief='raised', bd=2)
        left_panel.pack(side='left', fill='both', padx=(0, 10), pady=0)
        
        control_title = tk.Label(left_panel, text="🎨 Podešavanja", 
                                font=('Arial', 16, 'bold'), 
                                bg='white', fg='#333')
        control_title.pack(pady=15)
        
        # Font selection
        self.create_font_selector(left_panel)
        
        # Size slider
        self.create_size_slider(left_panel)
        
        # Weight selector
        self.create_weight_selector(left_panel)
        
        # Style selector
        self.create_style_selector(left_panel)
        
        # Color picker
        self.create_color_picker(left_panel)
        
        # Buttons
        self.create_buttons(left_panel)
        
        # Right panel - Text area
        right_panel = tk.Frame(main_container, bg='white', relief='raised', bd=2)
        right_panel.pack(side='right', fill='both', expand=True)
        
        preview_title = tk.Label(right_panel, text="📝 Tvoj tekst", 
                                font=('Arial', 16, 'bold'), 
                                bg='white', fg='#333')
        preview_title.pack(pady=15)
        
        # Text widget
        self.text_widget = scrolledtext.ScrolledText(
            right_panel,
            wrap=tk.WORD,
            width=50,
            height=25,
            font=(self.current_font, self.current_size),
            padx=15,
            pady=15,
            relief='flat',
            bg='#fafafa'
        )
        self.text_widget.pack(fill='both', expand=True, padx=15, pady=(0, 15))
        
        # Default text
        default_text = """Zdravo! Ovo je Font Changer desktop aplikacija.

Možeš da:
• Menjaš fontove iz liste
• Podešavaš veličinu teksta
• Biraš debljinu (bold, normal)
• Menjaš stil (italic, normal)
• Biraš boju teksta
• Kopiraš i čuvaš tekst

Probaj različite kombinacije!

✨ Uživaj u kreiranju! ✨"""
        
        self.text_widget.insert('1.0', default_text)
        
    def create_font_selector(self, parent):
        frame = tk.LabelFrame(parent, text="Font familija", 
                             bg='white', fg='#666', 
                             font=('Arial', 10, 'bold'),
                             padx=10, pady=10)
        frame.pack(fill='x', padx=15, pady=10)
        
        # Search box
        search_var = tk.StringVar()
        search_var.trace('w', lambda *args: self.filter_fonts(search_var.get()))
        
        search_entry = tk.Entry(frame, textvariable=search_var, 
                               font=('Arial', 10))
        search_entry.pack(fill='x', pady=(0, 5))
        
        # Listbox with scrollbar
        listbox_frame = tk.Frame(frame, bg='white')
        listbox_frame.pack(fill='both', expand=True)
        
        scrollbar = tk.Scrollbar(listbox_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.font_listbox = tk.Listbox(listbox_frame, 
                                       height=8,
                                       yscrollcommand=scrollbar.set,
                                       font=('Arial', 9))
        self.font_listbox.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.font_listbox.yview)
        
        for f in self.available_fonts:
            self.font_listbox.insert('end', f)
        
        self.font_listbox.bind('<<ListboxSelect>>', self.on_font_select)
        
    def filter_fonts(self, search_term):
        self.font_listbox.delete(0, 'end')
        for f in self.available_fonts:
            if search_term.lower() in f.lower():
                self.font_listbox.insert('end', f)
    
    def on_font_select(self, event):
        selection = self.font_listbox.curselection()
        if selection:
            self.current_font = self.font_listbox.get(selection[0])
            self.update_text_preview()
    
    def create_size_slider(self, parent):
        frame = tk.LabelFrame(parent, text="Veličina fonta", 
                             bg='white', fg='#666',
                             font=('Arial', 10, 'bold'),
                             padx=10, pady=10)
        frame.pack(fill='x', padx=15, pady=10)
        
        self.size_var = tk.IntVar(value=14)
        self.size_label = tk.Label(frame, text="14", 
                                   font=('Arial', 12, 'bold'),
                                   bg='white', fg='#7360f2')
        self.size_label.pack()
        
        slider = tk.Scale(frame, from_=8, to=72, 
                         orient='horizontal',
                         variable=self.size_var,
                         command=self.on_size_change,
                         bg='white', fg='#333',
                         highlightthickness=0,
                         troughcolor='#e0e0e0',
                         activebackground='#7360f2')
        slider.pack(fill='x')
    
    def on_size_change(self, value):
        self.current_size = int(value)
        self.size_label.config(text=str(self.current_size))
        self.update_text_preview()
    
    def create_weight_selector(self, parent):
        frame = tk.LabelFrame(parent, text="Debljina", 
                             bg='white', fg='#666',
                             font=('Arial', 10, 'bold'),
                             padx=10, pady=10)
        frame.pack(fill='x', padx=15, pady=10)
        
        self.weight_var = tk.StringVar(value="normal")
        
        weights = [("Normal", "normal"), ("Bold", "bold")]
        for text, value in weights:
            rb = tk.Radiobutton(frame, text=text, 
                               variable=self.weight_var,
                               value=value,
                               command=self.on_weight_change,
                               bg='white', fg='#333',
                               activebackground='white',
                               selectcolor='#7360f2')
            rb.pack(anchor='w')
    
    def on_weight_change(self):
        self.current_weight = self.weight_var.get()
        self.update_text_preview()
    
    def create_style_selector(self, parent):
        frame = tk.LabelFrame(parent, text="Stil", 
                             bg='white', fg='#666',
                             font=('Arial', 10, 'bold'),
                             padx=10, pady=10)
        frame.pack(fill='x', padx=15, pady=10)
        
        self.slant_var = tk.StringVar(value="roman")
        
        styles = [("Normal", "roman"), ("Italic", "italic")]
        for text, value in styles:
            rb = tk.Radiobutton(frame, text=text, 
                               variable=self.slant_var,
                               value=value,
                               command=self.on_style_change,
                               bg='white', fg='#333',
                               activebackground='white',
                               selectcolor='#7360f2')
            rb.pack(anchor='w')
    
    def on_style_change(self):
        self.current_slant = self.slant_var.get()
        self.update_text_preview()
    
    def create_color_picker(self, parent):
        frame = tk.LabelFrame(parent, text="Boja teksta", 
                             bg='white', fg='#666',
                             font=('Arial', 10, 'bold'),
                             padx=10, pady=10)
        frame.pack(fill='x', padx=15, pady=10)
        
        self.color_display = tk.Label(frame, text="     ", 
                                      bg=self.current_color,
                                      relief='solid', bd=1,
                                      width=10, height=2)
        self.color_display.pack(pady=5)
        
        btn = tk.Button(frame, text="🎨 Izaberi boju",
                       command=self.choose_color,
                       bg='#7360f2', fg='white',
                       relief='flat', cursor='hand2',
                       padx=10, pady=5)
        btn.pack()
    
    def choose_color(self):
        color = colorchooser.askcolor(title="Izaberi boju teksta")
        if color[1]:
            self.current_color = color[1]
            self.color_display.config(bg=self.current_color)
            self.update_text_preview()
    
    def create_buttons(self, parent):
        btn_frame = tk.Frame(parent, bg='white')
        btn_frame.pack(fill='x', padx=15, pady=15)
        
        copy_btn = tk.Button(btn_frame, text="📋 Kopiraj tekst",
                            command=self.copy_text,
                            bg='#7360f2', fg='white',
                            relief='flat', cursor='hand2',
                            padx=10, pady=8, width=15)
        copy_btn.pack(fill='x', pady=5)
        
        save_btn = tk.Button(btn_frame, text="💾 Sačuvaj u fajl",
                            command=self.save_to_file,
                            bg='#10b981', fg='white',
                            relief='flat', cursor='hand2',
                            padx=10, pady=8, width=15)
        save_btn.pack(fill='x', pady=5)
        
        clear_btn = tk.Button(btn_frame, text="🗑️ Obriši tekst",
                             command=self.clear_text,
                             bg='#ef4444', fg='white',
                             relief='flat', cursor='hand2',
                             padx=10, pady=8, width=15)
        clear_btn.pack(fill='x', pady=5)
    
    def update_text_preview(self):
        text_font = font.Font(
            family=self.current_font,
            size=self.current_size,
            weight=self.current_weight,
            slant=self.current_slant
        )
        self.text_widget.config(font=text_font, fg=self.current_color)
    
    def copy_text(self):
        text = self.text_widget.get('1.0', 'end-1c')
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Uspeh", "Tekst kopiran u clipboard!")
    
    def save_to_file(self):
        text = self.text_widget.get('1.0', 'end-1c')
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as file:
                    file.write(text)
                messagebox.showinfo("Uspeh", "Fajl sačuvan!")
            except Exception as e:
                messagebox.showerror("Greška", f"Greška pri čuvanju: {str(e)}")
    
    def clear_text(self):
        if messagebox.askyesno("Potvrda", "Da li želiš da obrišeš sav tekst?"):
            self.text_widget.delete('1.0', 'end')

if __name__ == '__main__':
    root = tk.Tk()
    app = FontChangerApp(root)
    root.mainloop()
